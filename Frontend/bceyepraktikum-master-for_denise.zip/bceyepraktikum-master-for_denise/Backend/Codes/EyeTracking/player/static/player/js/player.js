$(document).ready(function () {
    $("div.bhoechie-tab-menu>div.list-group>a").click(function (e) {
        e.preventDefault();
        $(this).siblings('a.active').removeClass("active");
        $(this).addClass("active");
        var index = $(this).index();
        $("div.bhoechie-tab>div.bhoechie-tab-content").removeClass("active");
        $("div.bhoechie-tab>div.bhoechie-tab-content").eq(index).addClass("active");
    });
});

var player,
    time_update_interval = 0;

function onYouTubeIframeAPIReady() {
    player = new YT.Player('video-placeholder', {
        width: 713,
        height: 367,
        videoId: 'LCfCWnM5zeY',	
        playerVars: {
            color: 'white',
            playlist: 'IfVhzIV7F1U,Ph77yOQFihc',
			controls: 0,
			modestbranding: 1,
			autohide: 1,
			showinfo: 0					
        },
        events: {
            onReady: initialize
        }
    });
}

function initialize(){

    // Update the controls on load
    updateTimerDisplay();
    updateProgressBar();

    // Clear any old interval.
    clearInterval(time_update_interval);

    // Start interval to update elapsed time display and
    // the elapsed part of the progress bar every second.
    time_update_interval = setInterval(function () {
        updateTimerDisplay();
        updateProgressBar();
    }, 1000);


    $('#volume-input').val(Math.round(player.getVolume()));
}


// This function is called by initialize()
function updateTimerDisplay(){
    // Update current time text display.
    $('#current-time').text(formatTime( player.getCurrentTime() ));
    $('#duration').text(formatTime( player.getDuration() ));
}


// This function is called by initialize()
function updateProgressBar(){
    // Update the value of our progress bar accordingly.
    $('.progress-bar').css("width",(player.getCurrentTime() / player.getDuration()) * 100 + "%");
}


// Progress bar

$('#progress-bar').on('mouseup touchend', function (e) {

    // Calculate the new time for the video.
    // new time in seconds = total duration in seconds * ( value of range input / 100 )
    var newTime = player.getDuration() * (e.target.value / 100);
	alert(e.target.value);
    // Skip video to new time.
    player.seekTo(newTime);

});


$('#progress-forward').on('click', function () {
	var newTime = player.getCurrentTime() + 10 ; 
	player.seekTo(newTime);
});

$('#progress-backward').on('click', function () {
	var newTime = player.getCurrentTime() - 10 ; 
    player.seekTo(newTime);
});


$(function() {
	// Playback

	$('#play').on('click', function (e) {
		e.preventDefault();
		player.playVideo();
		
		$('#play').hide();
		$('#pause').show();
	});


	$('#pause').on('click', function (e) {
		e.preventDefault();
		player.pauseVideo();
		
		$('#pause').hide();
		$('#play').show();
	});


	// Sound volume


	$('#mute-toggle').on('click', function(e) {
		e.preventDefault();
		var mute_toggle = $(this);
		
		if(player.isMuted()){
			mute_toggle.html('<a href="#" id="vol-down" style="float:left;"><span class="glyphicon glyphicon-minus" ></a>' +
								'<a href="#" id="mute-btn" style="float:left;"><span class="glyphicon glyphicon-volume-up" ></a>' + 
								'<a href="#" id="vol-up" style="float:left;"><span class="glyphicon glyphicon-plus" ></a>');
			mute_toggle.css("fontSize", "3.5em");
		}
		else{
			mute_toggle.html('<a href="#" id="vol-down" style="float:left;"><span class="glyphicon glyphicon-minus" ></a>' +
								'<a href="#" id="mute-btn" style="float:left;"><span class="glyphicon glyphicon-volume-off" ></a>' + 
								'<a href="#" id="vol-up" style="float:left;"><span class="glyphicon glyphicon-plus" ></a>');
			mute_toggle.css("fontSize", "3.5em");
		}
	});
	
	$( document ).on( 'click', '#mute-btn', function(e){
		e.preventDefault();
		var mute_toggle = $('#mute-toggle');
		if(player.isMuted()){
			player.unMute();
			mute_toggle.html('<span class="glyphicon glyphicon-volume-off fa-5x" style="padding-left:75px;padding-right:75px;"></span>');
			mute_toggle.css("fontSize", "1em");
		} else {
			player.mute();
			mute_toggle.html('<span class="glyphicon glyphicon-volume-up fa-5x" style="padding-left:75px;padding-right:75px;"></span>');
			mute_toggle.css("fontSize", "1em");
		}
		

		
	});
	
	var volume = 100;
	$( document ).on( 'click', '#vol-up', function(e){
		if(volume < 100){
			volume = volume + 15;
			player.setVolume(volume);
		}
	});
	$( document ).on( 'click', '#vol-down', function(e){
		if(volume > 0){
			volume = volume - 15;
			player.setVolume( volume );
		}

	});
	
	
	// fullscreen
	
		$('#fullscreen').on('click', function () {
			
		var fullscreenbtn = $(this);

		if ((document.fullScreenElement && document.fullScreenElement !== null) ||    
		   (!document.mozFullScreen && !document.webkitIsFullScreen)) {
			if (document.documentElement.requestFullScreen) {  
			  document.documentElement.requestFullScreen();  
			} else if (document.documentElement.mozRequestFullScreen) {  
			  document.documentElement.mozRequestFullScreen();  
			} else if (document.documentElement.webkitRequestFullScreen) {  
			  document.documentElement.webkitRequestFullScreen(Element.ALLOW_KEYBOARD_INPUT);  
			}  
			
			fullscreenbtn.empty();
			fullscreenbtn.append('<span class="glyphicon glyphicon-resize-small fa-5x" style="padding-left:75px;padding-right:75px;">');
			
			$('#header').hide();
			//$('.navbar').hide();
			$('.bhoechie-tab-menu').hide();
			$('#player-container').css("width", "100%");
			
			w = $(window).width();
			h = $(window).height();
			$("iframe").width(w);
			$("iframe").height(h-15);
			
		  } else {  
			if (document.cancelFullScreen) {  
			  document.cancelFullScreen();  
			} else if (document.mozCancelFullScreen) {  
			  document.mozCancelFullScreen();  
			} else if (document.webkitCancelFullScreen) {  
			  document.webkitCancelFullScreen();  
			}  
			
			fullscreenbtn.empty();
			fullscreenbtn.append('<span class="glyphicon glyphicon-fullscreen fa-5x" style="padding-left:75px;padding-right:75px;">');
			
			$('#header').show();
			$('.bhoechie-tab-menu').show();
			$('#player-container').css("width", "66.66666667%");
			
			$("iframe").width(713);
			$("iframe").height(367);
		  }  
	});


	// Other options


	$('#speed').on('change', function () {
		player.setPlaybackRate($(this).val());
	});

	$('#quality').on('change', function () {
		player.setPlaybackQuality($(this).val());
	});


	// Playlist

	$('#next').on('click', function () {
		player.nextVideo()
	});

	$('#prev').on('click', function () {
		player.previousVideo()
	});


	// Load video

	$('.related-video').on('click', function () {

		var url = $(this).attr('data-video-id');

		player.cueVideoById(url);

	});
	


});

// Helper Functions

function formatTime(time){
    time = Math.round(time);

    var minutes = Math.floor(time / 60),
        seconds = time - minutes * 60;

    seconds = seconds < 10 ? '0' + seconds : seconds;

    return minutes + ":" + seconds;
}




$(document).ready(function () {

        $('.btn-vertical-slider').on('click', function () {

            if ($(this).attr('data-slide') == 'next') {
                $('#myCarousel').carousel('next');
            }
            if ($(this).attr('data-slide') == 'prev') {
                $('#myCarousel').carousel('prev')
            }

        });
    });


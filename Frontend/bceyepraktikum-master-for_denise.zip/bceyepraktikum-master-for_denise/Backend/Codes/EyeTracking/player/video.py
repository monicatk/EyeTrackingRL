import requests
import json

youtube_key = 'AIzaSyDTouFE7y6JxiTeTE97drfplHhWmptHGQI'

def keyword_search(input):
    keyword_search_request = requests.get(
        "https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&q=" + input + "&key=" + youtube_key)
    keyword_search_dict = json.loads(keyword_search_request.text)

    search_results = []
    for item in keyword_search_dict['items']:
        id = item['id']['videoId']
        title = item['snippet']['title']
        description = item['snippet']['description']
        image = item['snippet']['thumbnails']['medium']['url']
        search_results.append(YouTubeVideo(id,title,description,image,0))
    return search_results

def similar_video_search(video_id):
    keyword_search_request = requests.get(
        "https://www.googleapis.com/youtube/v3/search?part=snippet&relatedToVideoId="+video_id+"&type=video&key=" + youtube_key)
    keyword_search_dict = json.loads(keyword_search_request.text)

    search_results = []
    for item in keyword_search_dict['items']:
        id = item['id']['videoId']
        title = item['snippet']['title']
        description = item['snippet']['description']
        image = item['snippet']['thumbnails']['medium']['url']
        search_results.append(YouTubeVideo(id,title,description,image,"3:0"))
    return search_results

def top_rated():
    count = 10
    keyword_search_request = requests.get(
        "https://www.googleapis.com/youtube/v3/videos?chart=mostPopular&part=snippet&type=video&maxResults=" + count + "&key=" + youtube_key)

    keyword_search_dict = json.loads(keyword_search_request.text)

    search_results = []
    for item in keyword_search_dict['items']:
        id = item['id']
        title = item['snippet']['title']
        description = item['snippet']['description']
        image = item['snippet']['thumbnails']['medium']['url']
        search_results.append(YouTubeVideo(id, title, description, image, "3:0"))
    return search_results

def get_duration():
    count = 10
    keyword_search_request = requests.get(
        "https://www.googleapis.com/youtube/v3/videos?chart=mostPopular&part=snippet&type=video&maxResults=" + count + "&key=" + youtube_key)

    keyword_search_dict = json.loads(keyword_search_request.text)

    search_results = []
    for item in keyword_search_dict['items']:
        id = item['id']
        title = item['snippet']['title']
        description = item['snippet']['description']
        image = item['snippet']['thumbnails']['medium']['url']
        search_results.append(YouTubeVideo(id, title, description, image, "3:0"))
    return search_results

class YouTubeVideo(object):

    video_id = ""
    title = ""
    description = ""
    image_url = ""
    duration = ""

    # The class "constructor" - It's actually an initializer
    def __init__(self, video_id, title, description, image_url, duration):
        self.video_id = video_id
        self.title = title
        self.description = description
        self.image_url = image_url
        self.duration = duration




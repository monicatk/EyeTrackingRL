from django.conf.urls import url
from . import views
app_name='player'

urlpatterns = [
    url(r'^$', views.PlayerIndexView.as_view(), name='index'),
    url(r'^register/$', views.UserFormView.as_view(), name='register'),
    url(r'^search/$', views.SearchView.as_view(), name="search"),
    url(r'^detail/(?P<video_id>[\w-]+)/$', views.DetailView.as_view(), name="detail"),
]
from django.views import generic
from django.views.generic.edit import CreateView, UpdateView, DeleteView
from .models import Video
from django.core.urlresolvers import reverse_lazy
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.views.generic import View
from .forms import UserForm
from player.video import *

# "player" and "search"
class PlayerIndexView(generic.ListView):
    template_name = 'player/index.html'
    context_object_name = 'all_videos'
    def get_queryset(self):
        videos = top_rated()
        return videos

#play a video
class DetailView(generic.ListView):
    template_name = 'player/player.html'

    context_object_name = 'all_videos'
    def get_queryset(self):
        video_id=self.kwargs['video_id']
        videos = similar_video_search(video_id)
        return videos

# search a video
class SearchView(generic.ListView):

    template_name = 'player/search.html'

    def get(self, request, *args, **kwargs):
        q = request.GET.get('q')
        videos = keyword_search(q)
        error = ''
        if not q:
            error = "error message"
        return render(request, self.template_name, {'error': error, 'all_videos': videos})

#"log-in"
class UserFormView(View):
    form_class= UserForm
    template_name= 'player/login.html'

    def get(self, request):
        form = self.form_class(None)
        return render(request, self.template_name, {'form':form})

    def post(self, request):
        form = self.form_class(request.POST)

        if form.is_valid():
            user=form.save(commit=False)

            #cleaned(normalized)data
            username= form.cleaned_data['username']
            password = form.cleaned_data['password']
            user.set_password(password)
            user.save()

            #returns User objects if credentials are correct
            user=authenticate(username=username,password=password)

            if user is not None:
                if user.is_active:
                    login(request,user)
                    return redirect('player:index')
        return render(request,self.template_name,{'form':form})

from django.db import models
from django.core.urlresolvers import reverse

class Video(models.Model):
    video_title = models.CharField(max_length=500)
    youtube_id = models.CharField(max_length=50)
    image_url = models.URLField(default=0)
    youtube_link = models.URLField(default=0)
    duration = models.IntegerField(default=0)

    def __str__(self):
        return self.video_title
    def get_absolute_url(self):
        return reverse('player:detail', kwargs={'pk':self.pk})